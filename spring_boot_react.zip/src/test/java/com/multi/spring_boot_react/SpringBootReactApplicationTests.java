package com.multi.spring_boot_react;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootReactApplicationTests {

	@Test
	void contextLoads() {
	}

}
